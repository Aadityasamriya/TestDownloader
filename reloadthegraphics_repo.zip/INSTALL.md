## System requirements

- node & npm
- yt-dlp available on PATH
- ffmpeg available on PATH

Optional: For production packaging, use electron-builder or similar.
